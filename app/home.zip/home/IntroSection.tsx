// app/components/IntroSection.tsx
'use client';

import * as React from 'react';
import Image from 'next/image';
import { motion, useReducedMotion } from 'framer-motion';

/* ================ Ultra-smooth Data Waves ================= */
function DataWaves({
  colors = ['#213F97', '#10B981', '#EF9601'],
  bars = 14,
  maxWidth = 480,
  gutter = 10,
  spacing = 22,
  barWidth = 9,
  barHeight = 56,
  duration = 6.0,          // 👈 slower default (was 3.0)
  delayStep = 0.24,        // 👈 slightly slower stagger (was 0.16)
  offsetX = 4,
  reflectionOpacity = 0.42,
  reflectionBlurPx = 2,
  speedMultiplier = 1.0,   // 👈 global speed knob: >1 = slower, <1 = faster
}: {
  colors?: string[]; bars?: number; maxWidth?: number; gutter?: number;
  spacing?: number; barWidth?: number; barHeight?: number; duration?: number;
  delayStep?: number; offsetX?: number; reflectionOpacity?: number; reflectionBlurPx?: number;
  speedMultiplier?: number;
}) {
  const colorAt = (i: number) => colors[i % colors.length];

  // Respect prefers-reduced-motion by stretching duration even more
  const prefersReduced = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  const effectiveDuration = (duration * speedMultiplier) * (prefersReduced ? 1.5 : 1); // 50% slower if user prefers less motion

  return (
    <div
      className="waves mx-auto"
      aria-hidden
      style={{
        maxWidth,
        transform: `translateX(${offsetX}px)`,
        ['--gutter' as any]: `${gutter}px`,
        ['--spacing' as any]: `${spacing}px`,
        ['--barW' as any]: `${barWidth}px`,
        ['--barH' as any]: `${barHeight}px`,
        ['--dur' as any]: `${effectiveDuration}s`,
        ['--delayStep' as any]: `${delayStep}s`,
        ['--reflOpacity' as any]: reflectionOpacity,
        ['--reflBlur' as any]: `${reflectionBlurPx}px`,
      }}
    >
      <div className="row top">
        {Array.from({ length: bars }).map((_, i) => (
          <div
            key={`t-${i}`}
            className="bar"
            style={{
              left: `calc(var(--gutter) + ${(i + 1)} * var(--spacing))`,
              animationDelay: `calc(${i + 1} * var(--delayStep))`,
              background: `linear-gradient(180deg, ${colorAt(i)} 0%, ${colorAt(i)} 70%, rgba(255,255,255,0.18) 100%)`,
              boxShadow: `0 6px 18px -8px ${colorAt(i)}33`,
            }}
          />
        ))}
      </div>

      <div className="axis" />

      <div className="row bottom">
        {Array.from({ length: bars }).map((_, i) => (
          <div
            key={`b-${i}`}
            className="bar"
            style={{
              left: `calc(var(--gutter) + ${(i + 1)} * var(--spacing))`,
              animationDelay: `calc(${i + 1} * var(--delayStep))`,
              background: `linear-gradient(180deg, ${colorAt(i)} 0%, ${colorAt(i)} 70%, rgba(255,255,255,0.18) 100%)`,
              boxShadow: `0 6px 18px -8px ${colorAt(i)}33`,
            }}
          />
        ))}
      </div>

      <style jsx>{`
        .waves { width: 100%; position: relative; }
        .row   { position: relative; height: calc(var(--barH) + 24px); width: 100%; }
        .row.bottom { transform: rotate(180deg); opacity: var(--reflOpacity); filter: blur(var(--reflBlur)); }
        .axis  { height: 2px; width: 100%; background: #213f97; opacity: 0.85; }

        .bar {
          position: absolute;
          bottom: 20px;
          width: var(--barW);
          height: var(--barH);
          border-radius: 999px;
          transform-origin: bottom;
          transform: translateX(0) translateY(2px) scaleY(0);
          animation: waveMotion var(--dur) cubic-bezier(0.33, 0.0, 0.23, 1) infinite;
          will-change: transform;
          backface-visibility: hidden;
        }

        @keyframes waveMotion {
          0%   { transform: translateX(0) translateY(2px) scaleY(0.02); }
          45%  { transform: translateX(0) translateY(0)    scaleY(1.0); }
          100% { transform: translateX(var(--spacing)) translateY(2px) scaleY(0.02); }
        }

        @media (prefers-reduced-motion: reduce) {
          .bar { animation: none; transform: translateX(0) translateY(1px) scaleY(0.5); }
        }
        @media (max-width: 480px) {
          .row { height: calc(var(--barH) + 16px); }
        }
      `}</style>
    </div>
  );
}

/* ===================== Intro Section ===================== */
export default function IntroSection() {
  const reduceMotion = useReducedMotion();

  return (
    <section aria-labelledby="intro-heading" className="relative bg-white overflow-hidden">
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 py-12 md:py-16">
        <div
          className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-10 items-stretch"
          style={{ ['--stack-h' as any]: '26rem' } as React.CSSProperties}
        >
          {/* Left: eyebrow + title + waves */}
          <div className="md:col-span-5 flex flex-col justify-center md:min-h-[var(--stack-h)]">
            <motion.div
              initial={reduceMotion ? false : { opacity: 0, y: -8 }}
              whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="md:col-span-5"
            >
              <span className="inline-flex items-center gap-2 rounded-full border border-black/10 bg-gray-100 px-3 py-1 text-[10px] tracking-wide mb-4">
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-400 animate-pulse" aria-hidden="true" />
                <span className="text-black/60">About EcoFocus</span>
              </span>
            </motion.div>

            <h2
              id="intro-heading"
              className="font-bold leading-tight text-slate-900 text-[clamp(1.8rem,4vw,2.6rem)]"
            >
              Trusted Insights for Purpose-Driven{' '}
              <span className="bg-gradient-to-r from-blue-500 via-teal-400 to-emerald-500 bg-clip-text text-transparent animate-gradient">
                Growth
              </span>
            </h2>

            <div className="mt-4 md:mt-5">
              {/* You can nudge overall speed here via speedMultiplier (e.g., 1.25 for even slower) */}
              <DataWaves speedMultiplier={1.0} />
            </div>
          </div>

          {/* Right: image + copy card */}
          <div className="md:col-span-7 relative md:min-h-[var(--stack-h)]">
            <div className="relative rounded-3xl bg-white/5 p-2 ring-1 ring-white/10 shadow-2xl">
              <div className="relative h-72 md:h-[var(--stack-h)] w-full rounded-2xl overflow-hidden shadow-lg">
                <Image
                  src="/images/intro-bg.png"
                  alt="EcoFocus sustainability research"
                  fill
                  className="object-cover"
                  priority
                />
              </div>
            </div>

            {/* 📱 Mobile: static flow (no absolute)  │  💻 md+: overlay float */}
            <div
              className="
                mt-6 w-[92%] mx-auto
                md:mt-0 md:absolute md:bottom-0 md:-left-12 md:translate-y-1/4
                md:w-[70%]
              "
            >
              <div className="rounded-2xl bg-white shadow-xl ring-1 ring-slate-200 p-6 md:p-8">
                <p className="text-sm sm:text-base text-slate-700 leading-relaxed">
                  EcoFocus® Research delivers consumer insights that can help companies turn purpose into a competitive edge.
                  Our syndicated and custom studies explore how attitudes, behaviors, and sentiment around sustainability influence purchase decisions.
                  With a special focus on the Purpose-Driven Generation, EcoFocus data can help companies build loyalty, reduce churn, and increase market share through purpose-aligned strategy and messaging.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-10 md:mt-12 h-px w-full bg-gradient-to-r from-transparent via-slate-200 to-transparent" />
      </div>
    </section>
  );
}














